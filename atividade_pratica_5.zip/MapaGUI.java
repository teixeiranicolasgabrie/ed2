package vitoria;

import com.mxgraph.layout.mxCircleLayout;
import com.mxgraph.model.mxCell;
import com.mxgraph.view.mxGraph;
import com.mxgraph.swing.mxGraphComponent;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.*;



public class MapaGUI extends JFrame {
    private Mapa mapa;
    private JComboBox<Cidade> origemComboBox;
    private JComboBox<Cidade> destinoComboBox;
    private JTextField distanciaField;
    private mxGraphComponent graphComponent;
    private JLabel custoField;

    private boolean ultimoCalculoPorDistancia;
    // Campos adicionados para seleção de cidade e aresta no grafo
    private Cidade cidadeSelecionada;
    private Aresta arestaSelecionada;

    public MapaGUI(Mapa mapa) {
        this.mapa = mapa;
        setTitle("Mapa de Cidades - Dijkstra");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initUI();
        visualizarGrafo(); // Mostrar o grafo ao iniciar
    }
    
    

    private void initUI() {
        origemComboBox = new JComboBox<>(mapa.getCidades().toArray(new Cidade[0]));
        destinoComboBox = new JComboBox<>(mapa.getCidades().toArray(new Cidade[0]));

        JButton calcularButton = new JButton("Caminho Mínimo");
        calcularButton.setPreferredSize(new Dimension(130, 30));
        calcularButton.setMargin(new Insets(5, 10, 5, 10));

        JButton limparButton = new JButton("Limpar Mapa");
        distanciaField = new JTextField();
        distanciaField.setEditable(false);
        distanciaField.setHorizontalAlignment(JTextField.CENTER);

        custoField = new JLabel("", SwingConstants.CENTER); // Inicializa o label para o custo
        custoField.setFont(custoField.getFont().deriveFont(Font.BOLD));

        JButton adicionarCidadeButton = new JButton("Adicionar Cidade");
        JButton adicionarArestaButton = new JButton("Adicionar Aresta");
        JButton removerCidadeButton = new JButton("Remover Cidade");
        JButton removerArestaButton = new JButton("Remover Aresta");
        JButton alterarArestaButton = new JButton("Alterar Aresta"); // Novo botão para alterar aresta

        calcularButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Cidade origem = (Cidade) origemComboBox.getSelectedItem();
                Cidade destino = (Cidade) destinoComboBox.getSelectedItem();
                if (origem != null && destino != null) {
                    if (!mapa.existeCaminho(origem, destino)) {
                        JOptionPane.showMessageDialog(MapaGUI.this, "Cidades impossíveis de conectar.");
                        return;
                    }

                    // Escolha do critério de cálculo
                    String[] options = {"Distância", "Custo de Pedágio"};
                    int escolha = JOptionPane.showOptionDialog(
                            MapaGUI.this,
                            "Calcular com base na distância ou no custo de pedágio?",
                            "Escolha de Critério",
                            JOptionPane.DEFAULT_OPTION,
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            options,
                            options[0]
                    );

                    if (escolha == -1) {
                        return; // Se o usuário cancelar a escolha, não faça nada
                    }

                    boolean calcularPorDistancia = escolha == 0;

                    Map<Cidade, Integer> distancias;
                    Map<Cidade, Cidade> antecessores;

                    if (calcularPorDistancia) {
                        distancias = Dijkstra.calcularMenorCaminho(mapa, origem);
                        antecessores = Dijkstra.getAntecessoresPorDistancia(mapa, origem);
                    } else {
                        distancias = Dijkstra.calcularMenorCustoPedagio(mapa, origem);
                        antecessores = Dijkstra.getAntecessoresPorPedagio(mapa, origem);
                    }
                    java.util.List<Cidade> caminho = Dijkstra.reconstruirCaminho(origem, destino, antecessores);
                    int distanciaFinal = calcularDistanciaFinal(caminho);
                    int custoPedagioFinal = calcularCustoPedagioFinal(caminho);

                    // Montar o texto de acordo com o critério escolhido
                    String custoTexto = "<html><b>Custo: ";
                    custoTexto += distanciaFinal + " Km + R$ " + custoPedagioFinal + " de pedágio</b></html>";
                    distanciaField.setText("Você irá rodar: " + distanciaFinal + " Km e gastar R$ " + custoPedagioFinal);
                    custoField.setText(custoTexto);

                    desenharCaminhoDistancia(caminho);
                }
            }
        });
        

        limparButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                origemComboBox.setSelectedIndex(-1);
                destinoComboBox.setSelectedIndex(-1);
                distanciaField.setText("");
                custoField.setText("");
                if (graphComponent != null) {
                    graphComponent.getGraph().getModel().beginUpdate();
                    try {
                        for (Object cell : graphComponent.getGraph().getChildCells(graphComponent.getGraph().getDefaultParent())) {
                            if (cell instanceof mxCell) {
                                ((mxCell) cell).setStyle(null);
                            }
                        }
                    } finally {
                        graphComponent.getGraph().getModel().endUpdate();
                    }
                    graphComponent.refresh();
                }
            }
        });

        adicionarCidadeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nomeCidade = JOptionPane.showInputDialog("Digite o nome da nova cidade:");
                if (nomeCidade != null && !nomeCidade.isEmpty()) {
                    Cidade novaCidade = new Cidade(nomeCidade);
                    mapa.adicionarCidade(novaCidade);
                    atualizarComboBoxes(); // Atualiza os comboboxes com a nova cidade
                    visualizarGrafo();
                }
            }
        });

        adicionarArestaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nomeOrigem = JOptionPane.showInputDialog("Digite o nome da cidade de origem:");
                String nomeDestino = JOptionPane.showInputDialog("Digite o nome da cidade de destino:");
                if (nomeOrigem != null && nomeDestino != null && !nomeOrigem.isEmpty() && !nomeDestino.isEmpty()) {
                    Cidade cidadeOrigem = mapa.getCidadePeloNome(nomeOrigem);
                    Cidade cidadeDestino = mapa.getCidadePeloNome(nomeDestino);
                    if (cidadeOrigem != null && cidadeDestino != null) {
                        int distancia = Integer.parseInt(JOptionPane.showInputDialog("Digite a distância da nova aresta:"));
                        int pedagio = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor do pedágio da nova aresta:"));
                        mapa.adicionarAresta(cidadeOrigem, cidadeDestino, distancia, pedagio);
                        visualizarGrafo();
                    } else {
                        JOptionPane.showMessageDialog(MapaGUI.this, "Cidade(s) não encontrada(s).");
                    }
                }
            }
        });

        removerCidadeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (cidadeSelecionada != null) {
                    mapa.removerCidade(cidadeSelecionada);
                    atualizarComboBoxes();
                    visualizarGrafo();
                    cidadeSelecionada = null; // Limpa a cidade selecionada
                } else {
                    JOptionPane.showMessageDialog(MapaGUI.this, "Selecione uma cidade no grafo para remover.");
                }
            }
        });

        removerArestaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (arestaSelecionada != null) {
                    mapa.removerAresta(arestaSelecionada.getOrigem(), arestaSelecionada.getDestino());
                    visualizarGrafo();
                    arestaSelecionada = null; // Limpa a aresta selecionada
                } else {
                    JOptionPane.showMessageDialog(MapaGUI.this, "Selecione uma aresta no grafo para remover.");
                }
            }
        });

        alterarArestaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (arestaSelecionada != null) {
                    String novaDistanciaStr = JOptionPane.showInputDialog("Digite a nova distância:");
                    String novoPedagioStr = JOptionPane.showInputDialog("Digite o novo valor do pedágio:");
                    if (novaDistanciaStr != null && !novaDistanciaStr.isEmpty() && novoPedagioStr != null && !novoPedagioStr.isEmpty()) {
                        try {
                            int novaDistancia = Integer.parseInt(novaDistanciaStr);
                            int novoPedagio = Integer.parseInt(novoPedagioStr);
                            arestaSelecionada.setDistancia(novaDistancia);
                            arestaSelecionada.setPedagio(novoPedagio);

                         // Atualiza também a aresta no sentido contrário, se existir (para grafos não direcionados)
                            Aresta arestaContraria = mapa.getAresta(arestaSelecionada.getDestino(), arestaSelecionada.getOrigem());
                            if (arestaContraria != null) {
                                arestaContraria.setDistancia(novaDistancia);
                                arestaContraria.setPedagio(novoPedagio);
                            }

                            visualizarGrafo(); // Atualiza o grafo após alterar a distância e pedágio da aresta
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(MapaGUI.this, "Por favor, insira valores válidos.");
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(MapaGUI.this, "Selecione uma aresta no grafo para alterar.");
                }
            }
        });

        JPanel controlsPanel = new JPanel(new BorderLayout());

        JPanel comboPanel = new JPanel(new GridLayout(4, 1, 0, 5));
        comboPanel.add(new JLabel("Origem:", SwingConstants.LEFT));
        comboPanel.add(origemComboBox);
        comboPanel.add(new JLabel("Destino:", SwingConstants.LEFT));
        comboPanel.add(destinoComboBox);
        comboPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel caminhoPanel = new JPanel(new BorderLayout(0, 5));
        caminhoPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        caminhoPanel.add(calcularButton, BorderLayout.NORTH);
        caminhoPanel.add(custoField, BorderLayout.CENTER);

        JPanel addRemovePanel = new JPanel(new GridLayout(1, 5, 5, 5)); // Alterado para GridLayout com 5 colunas
        addRemovePanel.add(adicionarCidadeButton);
        addRemovePanel.add(adicionarArestaButton);
        addRemovePanel.add(removerCidadeButton);
        addRemovePanel.add(removerArestaButton);
        addRemovePanel.add(alterarArestaButton); // Adicionado botão de alterar aresta

        controlsPanel.add(addRemovePanel, BorderLayout.SOUTH);
        controlsPanel.add(comboPanel, BorderLayout.WEST);
        controlsPanel.add(caminhoPanel, BorderLayout.CENTER);
        controlsPanel.add(limparButton, BorderLayout.EAST);
        controlsPanel.setPreferredSize(new Dimension(200, 150));
        controlsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JScrollPane scrollPane = new JScrollPane();
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        getContentPane().add(controlsPanel, BorderLayout.NORTH);
    }

    private void desenharCaminhoDistancia(java.util.List<Cidade> caminho) {
        if (graphComponent != null) {
            mxGraph graph = graphComponent.getGraph();
            graph.getModel().beginUpdate();
            try {
                // Resetar estilos de todas as células
                for (Object cell : graph.getChildCells(graph.getDefaultParent())) {
                    if (cell instanceof mxCell) {
                        mxCell mxCell = (mxCell) cell;
                        mxCell.setStyle(null); // Limpa o estilo de todas as células
                    }
                }

                // Aplicar estilos ao caminho encontrado
                for (int i = 0; i < caminho.size() - 1; i++) {
                    Cidade cidadeAtual = caminho.get(i);
                    Cidade proximaCidade = caminho.get(i + 1);

                    for (Object cell : graph.getChildCells(graph.getDefaultParent())) {
                        if (cell instanceof mxCell) {
                            mxCell edge = (mxCell) cell;
                            if (edge.isEdge()) {
                                mxCell source = (mxCell) edge.getSource();
                                mxCell target = (mxCell) edge.getTarget();
                                if (source.getValue().equals(cidadeAtual.getNome()) && target.getValue().equals(proximaCidade.getNome())) {
                                    edge.setStyle("strokeColor=red;strokeWidth=3;");
                                }
                            }
                        }
                    }
                }
            } finally {
                graph.getModel().endUpdate();
            }
            graphComponent.refresh();
        }
    }
        
    private void visualizarGrafo() {
        mxGraph graph = new mxGraph();
        Object parent = graph.getDefaultParent();
        graph.getModel().beginUpdate();
        try {
            // Limpar grafo anterior
            graph.removeCells(graph.getChildCells(parent));

            // Adicionar vértices
            HashMap<Cidade, Object> vertices = new HashMap<>();
            for (Cidade cidade : mapa.getCidades()) {
                Object vertex = graph.insertVertex(parent, null, cidade.getNome(), 20, 20, 80, 30);
                vertices.put(cidade, vertex);
            }

         // Adicionar arestas
            for (Aresta aresta : mapa.getArestas()) {
                Cidade origem = aresta.getOrigem();
                Cidade destino = aresta.getDestino();
                Object parentOrigem = vertices.get(origem);
                Object parentDestino = vertices.get(destino);
                String label = aresta.getDistancia() + " Km, R$" + aresta.getPedagio();
                graph.insertEdge(parent, null, label, parentOrigem, parentDestino);
            }

            // Adicionar evento de clique para capturar seleção de vértices e arestas
            if (graphComponent != null) {
                getContentPane().remove(graphComponent);
            }
            graphComponent = new mxGraphComponent(graph);
            getContentPane().add(graphComponent, BorderLayout.CENTER);

            graphComponent.getGraphControl().addMouseListener(new MouseAdapter() {
                @Override
                public void mouseReleased(MouseEvent e) {
                    Object cell = graphComponent.getCellAt(e.getX(), e.getY());
                    if (cell instanceof mxCell) {
                        mxCell clickedCell = (mxCell) cell;
                        if (clickedCell.isVertex()) {
                            cidadeSelecionada = mapa.getCidadePeloNome((String) clickedCell.getValue());
                            arestaSelecionada = null; // Limpa a aresta selecionada quando uma cidade é selecionada
                        } else if (clickedCell.isEdge()) {
                            mxCell source = (mxCell) clickedCell.getSource();
                            mxCell target = (mxCell) clickedCell.getTarget();
                            Cidade origem = mapa.getCidadePeloNome((String) source.getValue());
                            Cidade destino = mapa.getCidadePeloNome((String) target.getValue());
                            arestaSelecionada = mapa.getAresta(origem, destino); // Corrigido aqui para utilizar getAresta
                            cidadeSelecionada = null; // Limpa a cidade selecionada quando uma aresta é selecionada
                        }
                    }
                }
            });

            mxCircleLayout layout = new mxCircleLayout(graph);
            layout.execute(parent);
        } finally {
            graph.getModel().endUpdate();
        }
        validate();
    }

    private void atualizarComboBoxes() {
        origemComboBox.setModel(new DefaultComboBoxModel<>(mapa.getCidades().toArray(new Cidade[0])));
        destinoComboBox.setModel(new DefaultComboBoxModel<>(mapa.getCidades().toArray(new Cidade[0])));
    }
    
    private int calcularDistanciaFinal(java.util.List<Cidade> caminho) {
        int distanciaTotal = 0;
        for (int i = 0; i < caminho.size() - 1; i++) {
            Cidade cidadeAtual = caminho.get(i);
            Cidade proximaCidade = caminho.get(i + 1);
            Aresta aresta = mapa.getAresta(cidadeAtual, proximaCidade);
            if (aresta != null) {
                distanciaTotal += aresta.getDistancia();
            }
        }
        return distanciaTotal;
    }

    private int calcularCustoPedagioFinal(java.util.List<Cidade> caminho) {
        int custoPedagioTotal = 0;
        for (int i = 0; i < caminho.size() - 1; i++) {
            Cidade cidadeAtual = caminho.get(i);
            Cidade proximaCidade = caminho.get(i + 1);
            Aresta aresta = mapa.getAresta(cidadeAtual, proximaCidade);
            if (aresta != null) {
                custoPedagioTotal += aresta.getPedagio();
            }
        }
        return custoPedagioTotal;
    }

    public static void main(String[] args) {
        Mapa mapa = new Mapa();
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                MapaGUI gui = new MapaGUI(mapa);
                gui.setVisible(true);
            }
        });
    }
}
