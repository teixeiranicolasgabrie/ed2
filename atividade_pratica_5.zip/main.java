package vitoria;

import javax.swing.*;

public class main {
    public static void main(String[] args) {
        // Exibir caixa de diálogo para escolher entre iniciar vazio ou com cidades
        String[] options = {"Iniciar Vazio", "Iniciar com Cidades"};
        int choice = JOptionPane.showOptionDialog(
                null,
                "Como deseja iniciar o mapa?",
                "Escolha",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        Mapa mapa = new Mapa();

        // Adicionar cidades e arestas se a opção "Iniciar com Cidades" for escolhida
        if (choice == 1) {
            adicionarCidadesEConexoes(mapa);
        }

        // Iniciar a GUI do Mapa
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                MapaGUI frame = new MapaGUI(mapa);
                frame.setVisible(true);
            }
        });
    }

    private static void adicionarCidadesEConexoes(Mapa mapa) {
        // Criação das cidades
        Cidade sp = new Cidade("São Paulo");
        Cidade rj = new Cidade("Rio de Janeiro");
        Cidade campinas = new Cidade("Campinas");
        Cidade santos = new Cidade("Santos");
        Cidade sorocaba = new Cidade("Sorocaba");
        Cidade ribeiraoPreto = new Cidade("Ribeirão Preto");
        Cidade saoJoseCampos = new Cidade("São José dos Campos");
        Cidade barueri = new Cidade("Barueri");
        Cidade jundiai = new Cidade("Jundiaí");
        Cidade limeira = new Cidade("Limeira");
        Cidade piracicaba = new Cidade("Piracicaba");
        Cidade itu = new Cidade("Itu");
        Cidade bragancaPaulista = new Cidade("Bragança Paulista");
        Cidade americana = new Cidade("Americana");
        Cidade suzano = new Cidade("Suzano");
        Cidade araraquara = new Cidade("Araraquara");
        Cidade bauru = new Cidade("Bauru");
        Cidade marilia = new Cidade("Marília");
        Cidade presidentePrudente = new Cidade("Presidente Prudente");
        Cidade franca = new Cidade("Franca");

        // Adicionar cidades ao mapa
        mapa.adicionarCidade(sp);
        mapa.adicionarCidade(rj);
        mapa.adicionarCidade(campinas);
        mapa.adicionarCidade(santos);
        mapa.adicionarCidade(sorocaba);
        mapa.adicionarCidade(ribeiraoPreto);
        mapa.adicionarCidade(saoJoseCampos);
        mapa.adicionarCidade(barueri);
        mapa.adicionarCidade(jundiai);
        mapa.adicionarCidade(limeira);
        mapa.adicionarCidade(piracicaba);
        mapa.adicionarCidade(itu);
        mapa.adicionarCidade(bragancaPaulista);
        mapa.adicionarCidade(americana);
        mapa.adicionarCidade(suzano);
        mapa.adicionarCidade(araraquara);
        mapa.adicionarCidade(bauru);
        mapa.adicionarCidade(marilia);
        mapa.adicionarCidade(presidentePrudente);
        mapa.adicionarCidade(franca);

        // Adicionar arestas (conexões) entre as cidades
        mapa.adicionarAresta(sp, campinas, 100);
        mapa.adicionarAresta(sp, rj, 400);
        mapa.adicionarAresta(sp, santos, 75);
        mapa.adicionarAresta(sp, sorocaba, 90);
        mapa.adicionarAresta(sp, saoJoseCampos, 85);
        mapa.adicionarAresta(campinas, ribeiraoPreto, 180);
        mapa.adicionarAresta(campinas, limeira, 50);
        mapa.adicionarAresta(campinas, jundiai, 40);
        mapa.adicionarAresta(campinas, americana, 35);
        mapa.adicionarAresta(santos, suzano, 60);
        mapa.adicionarAresta(sorocaba, itu, 30);
        mapa.adicionarAresta(sorocaba, bragancaPaulista, 120);
        mapa.adicionarAresta(ribeiraoPreto, araraquara, 75);
        mapa.adicionarAresta(araraquara, bauru, 85);
        mapa.adicionarAresta(bauru, marilia, 95);
        mapa.adicionarAresta(marilia, presidentePrudente, 160);
        mapa.adicionarAresta(presidentePrudente, franca, 200);
        mapa.adicionarAresta(franca, ribeiraoPreto, 70);
        mapa.adicionarAresta(limeira, piracicaba, 25);
        mapa.adicionarAresta(barueri, sp, 35);
    }
}
