package vitoria;

import java.util.*;

public class Mapa {
    private Map<Cidade, List<Aresta>> adjacencias = new HashMap<>();

    public void adicionarCidade(Cidade cidade) {
        adjacencias.putIfAbsent(cidade, new ArrayList<>());
    }

    public void adicionarAresta(Cidade origem, Cidade destino, int distancia, int pedagio) {
        adicionarAresta(new Aresta(origem, destino, distancia, pedagio));
    }

    public void adicionarAresta(Aresta aresta) {
        Cidade origem = aresta.getOrigem();
        Cidade destino = aresta.getDestino();
        int distancia = aresta.getDistancia();
        int pedagio = aresta.getPedagio();

        adjacencias.putIfAbsent(origem, new ArrayList<>());
        adjacencias.putIfAbsent(destino, new ArrayList<>());

        adjacencias.get(origem).add(aresta);

        // Para grafos não-direcionados, adiciona a aresta também para o destino
        adjacencias.get(destino).add(new Aresta(destino, origem, distancia, pedagio));
    }

    public void modificarAresta(Cidade origem, Cidade destino, int novaDistancia, int novoPedagio) {
        List<Aresta> arestasOrigem = adjacencias.get(origem);
        if (arestasOrigem != null) {
            for (Aresta aresta : arestasOrigem) {
                if (aresta.getDestino().equals(destino)) {
                    aresta.setDistancia(novaDistancia);
                    aresta.setPedagio(novoPedagio);
                    break;
                }
            }
        }

        // Modifica também a aresta no sentido contrário, se existir (para grafos não direcionados)
        List<Aresta> arestasDestino = adjacencias.get(destino);
        if (arestasDestino != null) {
            for (Aresta aresta : arestasDestino) {
                if (aresta.getDestino().equals(origem)) {
                    aresta.setDistancia(novaDistancia);
                    aresta.setPedagio(novoPedagio);
                    break;
                }
            }
        }
    }

    public List<Cidade> getCidades() {
        return new ArrayList<>(adjacencias.keySet());
    }

    public List<Aresta> getArestas() {
        List<Aresta> listaArestas = new ArrayList<>();
        for (List<Aresta> arestas : adjacencias.values()) {
            listaArestas.addAll(arestas);
        }
        return listaArestas;
    }

    public Aresta getAresta(Cidade origem, Cidade destino) {
        List<Aresta> arestasOrigem = adjacencias.get(origem);
        if (arestasOrigem != null) {
            for (Aresta aresta : arestasOrigem) {
                if (aresta.getDestino().equals(destino)) {
                    return aresta;
                }
            }
        }
        return null;  // Retorna null se não encontrar a aresta entre origem e destino
    }

    public void removerCidade(Cidade cidade) {
        // Remove a cidade do mapa de adjacências
        adjacencias.remove(cidade);

        // Remove todas as arestas que conectam à cidade removida
        for (List<Aresta> arestas : adjacencias.values()) {
            arestas.removeIf(aresta -> aresta.getDestino().equals(cidade));
        }
    }

    public void removerAresta(Cidade origem, Cidade destino) {
        // Remove a aresta da lista de adjacências da cidade de origem
        List<Aresta> arestasOrigem = adjacencias.get(origem);
        if (arestasOrigem != null) {
            arestasOrigem.removeIf(aresta -> aresta.getDestino().equals(destino));
        }

        // Remove a aresta da lista de adjacências da cidade de destino (para grafos não-direcionados)
        List<Aresta> arestasDestino = adjacencias.get(destino);
        if (arestasDestino != null) {
            arestasDestino.removeIf(aresta -> aresta.getDestino().equals(origem));
        }
    }

    public List<Aresta> getAdjacencias(Cidade cidade) {
        return adjacencias.get(cidade);
    }

    public Cidade getCidadePeloNome(String nome) {
        for (Cidade cidade : adjacencias.keySet()) {
            if (cidade.getNome().equals(nome)) {
                return cidade;
            }
        }
        return null; // Retorna null se a cidade não for encontrada
    }

    public boolean existeCaminho(Cidade origem, Cidade destino) {
        if (origem.equals(destino)) {
            return true; // Caso especial: origem e destino são iguais
        }

        Set<Cidade> visitadas = new HashSet<>();
        Queue<Cidade> fila = new LinkedList<>();
        visitadas.add(origem);
        fila.offer(origem);

        while (!fila.isEmpty()) {
            Cidade atual = fila.poll();
            for (Aresta aresta : adjacencias.get(atual)) {
                Cidade proxima = aresta.getDestino();
                if (!visitadas.contains(proxima)) {
                    if (proxima.equals(destino)) {
                        return true;
                    }
                    visitadas.add(proxima);
                    fila.offer(proxima);
                }
            }
        }

        return false;
    }
}
