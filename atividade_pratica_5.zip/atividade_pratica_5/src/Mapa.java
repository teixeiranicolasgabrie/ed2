import java.util.*;

public class Mapa {
    private Map<Cidade, List<Aresta>> adjacencias = new HashMap<>();

    public void adicionarCidade(Cidade cidade) {
        adjacencias.putIfAbsent(cidade, new ArrayList<>());
    }

    public void adicionarAresta(Cidade origem, Cidade destino, int distancia) {
        adjacencias.get(origem).add(new Aresta(destino, distancia));
        adjacencias.get(destino).add(new Aresta(origem, distancia)); // Para grafo não-direcionado
    }

    public List<Cidade> getCidades() {
        return new ArrayList<>(adjacencias.keySet());
    }

    public List<Aresta> getAdjacencias(Cidade cidade) {
        return adjacencias.get(cidade);
    }
}
