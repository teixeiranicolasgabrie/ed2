import com.mxgraph.layout.mxCircleLayout;
import com.mxgraph.model.mxCell;
import com.mxgraph.view.mxGraph;
import com.mxgraph.swing.mxGraphComponent;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

public class MapaGUI extends JFrame {
    private Mapa mapa;
    private JComboBox<Cidade> origemComboBox;
    private JComboBox<Cidade> destinoComboBox;
    private JTextArea resultadoArea;
    private mxGraphComponent graphComponent;

    public MapaGUI(Mapa mapa) {
        this.mapa = mapa;
        setTitle("Mapa de Cidades - Dijkstra");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initUI();
        visualizarGrafo(); // Mostrar o grafo ao iniciar
    }

    private void initUI() {
        origemComboBox = new JComboBox<>(mapa.getCidades().toArray(new Cidade[0]));
        destinoComboBox = new JComboBox<>(mapa.getCidades().toArray(new Cidade[0]));
        JButton calcularButton = new JButton("Calcular Menor Caminho");
        JButton limparButton = new JButton("Limpar");
        JButton visualizarGrafoButton = new JButton("Visualizar Grafo");
        resultadoArea = new JTextArea();
        resultadoArea.setEditable(false);

        calcularButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Cidade origem = (Cidade) origemComboBox.getSelectedItem();
                Cidade destino = (Cidade) destinoComboBox.getSelectedItem();
                if (origem != null && destino != null) {
                    Map<Cidade, Integer> distancias = Dijkstra.calcularMenorCaminho(mapa, origem);
                    Map<Cidade, Cidade> antecessores = Dijkstra.getAntecessores(mapa, origem);
                    java.util.List<Cidade> caminho = Dijkstra.reconstruirCaminho(origem, destino, antecessores);
                    resultadoArea.setText("Distância mínima de " + origem.getNome() + " até " + destino.getNome() + ": " + distancias.get(destino) + " km");
                    resultadoArea.append("\nCaminho: " + caminho);

                    // Desenhar o caminho no grafo
                    desenharCaminho(caminho);
                }
            }
        });

        limparButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                origemComboBox.setSelectedIndex(-1);
                destinoComboBox.setSelectedIndex(-1);
                resultadoArea.setText("");
                if (graphComponent != null) {
                    graphComponent.getGraph().getModel().beginUpdate();
                    try {
                        for (Object cell : graphComponent.getGraph().getChildCells(graphComponent.getGraph().getDefaultParent())) {
                            if (cell instanceof mxCell) {
                                ((mxCell) cell).setStyle(null);
                            }
                        }
                    } finally {
                        graphComponent.getGraph().getModel().endUpdate();
                    }
                    graphComponent.refresh();
                }
            }
        });

        visualizarGrafoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                visualizarGrafo();
            }
        });

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("Origem:"));
        panel.add(origemComboBox);
        panel.add(new JLabel("Destino:"));
        panel.add(destinoComboBox);
        panel.add(calcularButton);
        panel.add(limparButton);
        panel.add(visualizarGrafoButton);

        getContentPane().add(panel, BorderLayout.NORTH);
        getContentPane().add(new JScrollPane(resultadoArea), BorderLayout.SOUTH);
    }

    private void desenharCaminho(java.util.List<Cidade> caminho) {
        mxGraph graph = graphComponent.getGraph();
        graph.getModel().beginUpdate();
        try {
            for (int i = 0; i < caminho.size() - 1; i++) {
                Cidade cidadeAtual = caminho.get(i);
                Cidade proximaCidade = caminho.get(i + 1);

                for (Object cell : graph.getChildCells(graph.getDefaultParent())) {
                    if (cell instanceof mxCell) {
                        mxCell edge = (mxCell) cell;
                        if (edge.isEdge()) {
                            mxCell source = (mxCell) edge.getSource();
                            mxCell target = (mxCell) edge.getTarget();
                            if (source.getValue().equals(cidadeAtual.getNome()) && target.getValue().equals(proximaCidade.getNome())) {
                                edge.setStyle("strokeColor=red;strokeWidth=2");
                            }
                        }
                    }
                }
            }
        } finally {
            graph.getModel().endUpdate();
        }
        graphComponent.refresh();
    }
    
    private void visualizarGrafo() {
        mxGraph graph = new mxGraph();
        Object parent = graph.getDefaultParent();

        graph.getModel().beginUpdate();
        try {
            Map<Cidade, Object> vertices = new HashMap<>();
            for (Cidade cidade : mapa.getCidades()) {
                Object vertex = graph.insertVertex(parent, null, cidade.getNome(), 100, 100, 80, 30);
                vertices.put(cidade, vertex);
            }
            for (Cidade cidade : mapa.getCidades()) {
                for (Aresta aresta : mapa.getAdjacencias(cidade)) {
                    graph.insertEdge(parent, null, aresta.getDistancia() + " km", vertices.get(cidade), vertices.get(aresta.getDestino()));
                }
            }
        } finally {
            graph.getModel().endUpdate();
        }

        mxCircleLayout layout = new mxCircleLayout(graph);
        layout.execute(graph.getDefaultParent());

        if (graphComponent == null) {
            graphComponent = new mxGraphComponent(graph);
            graphComponent.setPreferredSize(new Dimension(800, 400));  // Define o tamanho preferido do componente do grafo
            getContentPane().add(graphComponent, BorderLayout.CENTER);
        } else {
            graphComponent.setGraph(graph);
            graphComponent.getGraphControl().updateUI();
        }

        validate();
        repaint();
    }
}
