package atividade_pratica_5;

import java.util.*;

public class Dijkstra {
    public static Map<Cidade, Integer> calcularMenorCaminho(Mapa mapa, Cidade origem) {
        Map<Cidade, Integer> distancias = new HashMap<>();
        Map<Cidade, Cidade> antecessores = new HashMap<>();
        PriorityQueue<Cidade> queue = new PriorityQueue<>(Comparator.comparingInt(distancias::get));

        for (Cidade cidade : mapa.getCidades()) {
            if (cidade.equals(origem)) {
                distancias.put(cidade, 0);
            } else {
                distancias.put(cidade, Integer.MAX_VALUE);
            }
            queue.add(cidade);
        }

        while (!queue.isEmpty()) {
            Cidade cidadeAtual = queue.poll();

            for (Aresta aresta : mapa.getAdjacencias(cidadeAtual)) {
                Cidade destino = aresta.getDestino();
                int novaDistancia = distancias.get(cidadeAtual) + aresta.getDistancia();

                if (novaDistancia < distancias.get(destino)) {
                    queue.remove(destino);
                    distancias.put(destino, novaDistancia);
                    antecessores.put(destino, cidadeAtual);
                    queue.add(destino);
                }
            }
        }

        return distancias;
    }

    public static Map<Cidade, Cidade> getAntecessoresPorDistancia(Mapa mapa, Cidade origem) {
        Map<Cidade, Integer> distancias = new HashMap<>();
        Map<Cidade, Cidade> antecessores = new HashMap<>();
        PriorityQueue<Cidade> queue = new PriorityQueue<>(Comparator.comparingInt(distancias::get));

        for (Cidade cidade : mapa.getCidades()) {
            if (cidade.equals(origem)) {
                distancias.put(cidade, 0);
            } else {
                distancias.put(cidade, Integer.MAX_VALUE);
            }
            queue.add(cidade);
        }

        while (!queue.isEmpty()) {
            Cidade cidadeAtual = queue.poll();

            for (Aresta aresta : mapa.getAdjacencias(cidadeAtual)) {
                Cidade destino = aresta.getDestino();
                int novaDistancia = distancias.get(cidadeAtual) + aresta.getDistancia();

                if (novaDistancia < distancias.get(destino)) {
                    queue.remove(destino);
                    distancias.put(destino, novaDistancia);
                    antecessores.put(destino, cidadeAtual);
                    queue.add(destino);
                }
            }
        }

        return antecessores;
    }

    public static Map<Cidade, Cidade> getAntecessoresPorPedagio(Mapa mapa, Cidade origem) {
        Map<Cidade, Integer> custosPedagio = new HashMap<>();
        Map<Cidade, Cidade> antecessores = new HashMap<>();
        PriorityQueue<Cidade> queue = new PriorityQueue<>(Comparator.comparingInt(custosPedagio::get));

        for (Cidade cidade : mapa.getCidades()) {
            if (cidade.equals(origem)) {
                custosPedagio.put(cidade, 0);
            } else {
                custosPedagio.put(cidade, Integer.MAX_VALUE);
            }
            queue.add(cidade);
        }

        while (!queue.isEmpty()) {
            Cidade cidadeAtual = queue.poll();

            for (Aresta aresta : mapa.getAdjacencias(cidadeAtual)) {
                Cidade destino = aresta.getDestino();
                int novoCustoPedagio = custosPedagio.get(cidadeAtual) + aresta.getPedagio();

                if (novoCustoPedagio < custosPedagio.get(destino)) {
                    queue.remove(destino);
                    custosPedagio.put(destino, novoCustoPedagio);
                    antecessores.put(destino, cidadeAtual);
                    queue.add(destino);
                }
            }
        }

        return antecessores;
    }

    public static List<Cidade> reconstruirCaminho(Cidade origem, Cidade destino, Map<Cidade, Cidade> antecessores) {
        List<Cidade> caminho = new ArrayList<>();
        for (Cidade at = destino; at != null; at = antecessores.get(at)) {
            caminho.add(at);
        }
        Collections.reverse(caminho);
        return caminho;
    }

    // Novo método para calcular o menor custo de pedágio
    public static Map<Cidade, Integer> calcularMenorCustoPedagio(Mapa mapa, Cidade origem) {
        Map<Cidade, Integer> custos = new HashMap<>();
        Map<Cidade, Cidade> antecessores = new HashMap<>();
        PriorityQueue<Cidade> queue = new PriorityQueue<>(Comparator.comparingInt(custos::get));

        for (Cidade cidade : mapa.getCidades()) {
            if (cidade.equals(origem)) {
                custos.put(cidade, 0);
            } else {
                custos.put(cidade, Integer.MAX_VALUE);
            }
            queue.add(cidade);
        }

        while (!queue.isEmpty()) {
            Cidade cidadeAtual = queue.poll();

            for (Aresta aresta : mapa.getAdjacencias(cidadeAtual)) {
                Cidade destino = aresta.getDestino();
                int novoCusto = custos.get(cidadeAtual) + aresta.getPedagio(); // Considerando o pedágio

                if (novoCusto < custos.get(destino)) {
                    queue.remove(destino);
                    custos.put(destino, novoCusto);
                    antecessores.put(destino, cidadeAtual);
                    queue.add(destino);
                }
            }
        }

        return custos;
    }
    
    public static int calcularDistanciaFinal(Mapa mapa, Cidade origem, Cidade destino) {
        Map<Cidade, Integer> distancias = calcularMenorCaminho(mapa, origem);
        return distancias.get(destino); // Retorna a distância até o destino
    }
    
    public static int calcularCustoPedagioFinal(Mapa mapa, Cidade origem, Cidade destino) {
        Map<Cidade, Integer> custosPedagio = calcularMenorCustoPedagio(mapa, origem);
        return custosPedagio.get(destino); // Retorna o custo de pedágio até o destino
    }
    
}
