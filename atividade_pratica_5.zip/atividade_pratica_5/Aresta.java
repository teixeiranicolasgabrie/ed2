package atividade_pratica_5;

public class Aresta {
    private Cidade origem;
    private Cidade destino;
    private int distancia;
    private int pedagio; // Novo campo para pedágio

    public Aresta(Cidade origem, Cidade destino, int distancia, int pedagio) {
        this.origem = origem;
        this.destino = destino;
        this.distancia = distancia;
        this.pedagio = pedagio; // Inicializa o pedágio
    }

    public Cidade getDestino() {
        return destino;
    }

    public void setDestino(Cidade destino) {
        this.destino = destino;
    }

    public int getDistancia() {
        return distancia;
    }

    public void setDistancia(int distancia) {
        this.distancia = distancia;
    }

    public Cidade getOrigem() {
        return origem;
    }

    public void setOrigem(Cidade origem) {
        this.origem = origem;
    }

    public int getPedagio() {
        return pedagio; // Getter para pedágio
    }

    public void setPedagio(int pedagio) {
        this.pedagio = pedagio; // Setter para pedágio
    }
}
